from django.apps import AppConfig


class PhychicsGuessNumConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'phychics_guess_num'
